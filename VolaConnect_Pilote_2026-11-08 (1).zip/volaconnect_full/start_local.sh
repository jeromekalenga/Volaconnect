#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
PORT="${PORT:-8000}"
echo "VolaConnect local : http://localhost:${PORT}"
echo "Pour arrêter : Ctrl+C"
python3 -m http.server "$PORT"
