# VolaConnect — édition pilote web et mobile

VolaConnect est une application web progressive (PWA) pour le suivi d'une exploitation avicole : fiche de ferme, cheptel et santé, dépenses/recettes, catalogue local de produits, avis, messagerie locale, GPS, estimation de superficie et sauvegarde des données.

## Langues

L'interface propose le français (par défaut), l'anglais, le swahili, le lingala et le bemba de Zambie. Il s'agit d'une première traduction des éléments de navigation et des principaux formulaires. Une relecture par des locuteurs natifs est recommandée avant une diffusion institutionnelle ou commerciale, en particulier pour le bemba.

## Démarrage rapide — tester sur ordinateur

Prérequis : Python 3 ou Node.js.

1. Décompresser le dossier.
2. Ouvrir un terminal dans le dossier `volaconnect_full`.
3. Lancer `python3 -m http.server 8000`.
4. Ouvrir `http://localhost:8000` dans Chrome, Edge ou Firefox.
5. Dans Administration, choisir la langue et configurer la ferme. Les données sont conservées dans le navigateur.

Pour arrêter le serveur local : `Ctrl+C` dans le terminal.

## Installer sur téléphone

Pour installer la PWA sur Android ou iPhone, publier les fichiers web (`index.html`, `app.js`, `sw.js`, `manifest.webmanifest`) sur un hébergement HTTPS. Ouvrir ensuite l'adresse dans Chrome (Android) ou Safari (iPhone) et choisir « Installer l'application » / « Ajouter à l'écran d'accueil ». Le GPS et le service worker nécessitent HTTPS, sauf en environnement `localhost`.

## Synchronisation entre appareils — configuration serveur nécessaire

Le mode hors ligne conserve les données localement. La synchronisation entre plusieurs appareils fonctionne lorsque l'API VolaConnect est déployée en HTTPS et qu'un utilisateur se connecte au même compte sur chaque appareil.

1. Installer Docker et Docker Compose sur un serveur Linux.
2. Dans ce dossier, copier `server/.env.example` vers `server/.env`.
3. Générer des secrets longs et uniques pour `JWT_SECRET` et `PAYMENT_WEBHOOK_SECRET` (au moins 32 caractères aléatoires).
4. Définir `CORS_ORIGIN` avec l'adresse HTTPS exacte de l'interface web.
5. Définir `POSTGRES_PASSWORD` dans un fichier `.env` à la racine du projet avec un mot de passe fort.
6. Démarrer avec `docker compose up --build -d`.
7. Appliquer le schéma avec `docker compose exec api node src/migrate.js`.
8. Vérifier `https://adresse-api/health`.
9. Dans l'application, ouvrir Administration, saisir l'adresse HTTPS de l'API, créer un compte ou se connecter, puis lancer la synchronisation.

Les modifications restent sur l'appareil quand Internet est absent. Dès que la connexion revient, l'application peut synchroniser avec le cloud. Pour éviter qu'un appareil écrase silencieusement les changements d'un autre, une détection de conflit par version est activée : en cas de conflit, l'utilisateur doit choisir la sauvegarde à conserver. Exportez régulièrement une sauvegarde JSON depuis Administration.

**Important :** cette synchronisation cloud stocke une sauvegarde JSON par compte, avec contrôle de version. Elle ne remplace pas encore une synchronisation métier avancée avec fusion automatique de chaque enregistrement.

## Modules optionnels

- **IA :** interface de préparation d'observation uniquement. Aucun diagnostic IA n'est activé. Un fournisseur IA pourra être intégré ultérieurement côté serveur, avec protection des données et validation vétérinaire.
- **Paiements :** M-Pesa, Orange Money et Airtel Money ne sont pas activés. Le serveur contient un point de départ pour les intentions de paiement, mais aucun débit réel n'est possible avant l'intégration contractuelle et technique des API officielles.
- **Audio/vidéo :** les boutons sont informatifs; aucun appel réel n'est connecté.
- **Cartographie :** le GPS fonctionne avec permission explicite; la carte interactive nécessite un fournisseur cartographique et une clé de service.

## État et limites avant ouverture publique

Cette livraison est une **version pilote utilisable pour les essais et la saisie locale**, accompagnée d'un backend de démarrage. Ce n'est pas encore un service public hébergé et audité. Avant d'ouvrir les inscriptions au grand public, il faut notamment : déployer sur un domaine, activer HTTPS, renforcer la gestion des comptes et des sessions, tester les autorisations et les sauvegardes, faire auditer la sécurité, mettre en place la supervision et valider les traductions. Les fonctionnalités non activées ci-dessus ne doivent pas être présentées comme opérationnelles.
