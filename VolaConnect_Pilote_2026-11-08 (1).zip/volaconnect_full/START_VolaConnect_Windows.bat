@echo off
cd /d "%~dp0"
echo VolaConnect local : http://localhost:8000
echo Pour arreter : Ctrl+C
py -m http.server 8000
pause
