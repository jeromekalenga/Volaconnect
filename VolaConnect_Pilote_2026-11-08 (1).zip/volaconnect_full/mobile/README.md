# Accès mobile

La PWA fournie est responsive et peut être installée depuis un navigateur compatible lorsque le site est servi en HTTPS. Pour produire ultérieurement des paquets natifs Android/iOS, intégrer le frontend dans Capacitor après raccordement à l'API :

1. `npm install @capacitor/core @capacitor/cli`
2. `npx cap init VolaConnect cd.volaconnect.app --web-dir=www`
3. Copier le build web dans `www/`, puis `npx cap add android` et/ou `npx cap add ios`.
4. Configurer les permissions GPS, caméra, microphone et notifications avec des demandes explicites à l'utilisateur.
5. Tester les comportements hors ligne, la gestion des permissions et les versions minimales des systèmes avant publication sur les stores.

Ce dossier est un guide d'emballage mobile; aucun binaire signé n'est généré dans cette livraison.
